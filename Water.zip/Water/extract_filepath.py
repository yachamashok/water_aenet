#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Mar  3 10:31:16 2023

@author: Ashok
"""

import glob
xsf_files = glob.glob("*.xsf")
sorted_files = sorted(xsf_files)
output_file = open("h20_struct_path.txt", "w")
for file_path in sorted_files:
    output_file.write(file_path+ '\n')
    